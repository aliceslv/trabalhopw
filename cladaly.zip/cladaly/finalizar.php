<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION["clienteid"])) {
    header("Location: login.php");
    exit;
}
if (empty($_SESSION["carrinho"])) {
    header("Location: carrinho.php");
    exit;
}

$titulopag = "Finalizar Compra";
include "header.php";

$mensagem = "";
$tipo = "";

$nome = $_SESSION["carrinho"]["nome"];
$preco = $_SESSION["carrinho"]["preco"];

if (isset($_POST["finalizar"])) {
    $cliente = $_SESSION["clienteid"];
    $forma = $_POST["formapag"];
    $endereco = $_POST["endereco"];

if ($forma == "" || $endereco == "") {
    $mensagem = "Preencha todos os campos.";
    $tipo = "erro";

} else {
    $sql = "INSERT INTO pedidos(cliente_id, total)
            VALUES('$cliente', '$preco')";
    $pedido = mysqli_query($conexao, $sql);

if ($pedido) {
    $pedidoid = mysqli_insert_id($conexao);
    $sql = "INSERT INTO pagamentos(pedido_id, forma_pagamento, valor)
            VALUES('$pedidoid', '$forma', '$preco')";
    $pagamento = mysqli_query($conexao, $sql);

if ($pagamento) {
    $sql = "INSERT INTO entregas(pedido_id, endereco)
            VALUES('$pedidoid', '$endereco')";
    $entrega = mysqli_query($conexao, $sql);

if ($entrega) {
    $_SESSION["carrinho"] = [];
    $mensagem = "Pedido #$pedidoid realizado com sucesso!";
    $tipo = "sucesso";
        }
    }
}
}
}
?>
<div class="banner bannerprod">
    <h1>Finalizar Compra</h1>
</div>

<section class="secao">
<?php if ($mensagem != "") { ?>
<div class="aviso <?php echo $tipo; ?>">
    <?php echo $mensagem; ?>
</div>
<?php } ?>

<?php if ($tipo != "sucesso") { ?>
<div class="final">
<div class="finalresumo">
<h3 class="finaltitulo">Resumo do Pedido</h3>

<div class="finalitem">
    <div class="finalinfo">
    <span class="finalnome">
    <?php echo $nome; ?>
    </span>
    <span class="finalpreco">
    R$ <?php echo number_format($preco,2,",","."); ?>
    </span>
</div>
</div>

<div class="finaltotal">
    <span>Total</span>
    <span class="finalvalor">
    R$ <?php echo number_format($preco,2,",","."); ?>
    </span>
</div>
</div>

<form action="finalizar.php" method="POST" class="finalform">
<div class="finalbloco">
<h3 class="finaltitulo">Endereço de Entrega</h3>

<label>Endereço completo</label>
    <input type="text" name="endereco" required value="<?php if(isset($_POST['endereco'])) echo $_POST['endereco']; ?>">
</div>

<div class="finalbloco">
<h3 class="finaltitulo">Forma de Pagamento</h3>

<div class="formapag">
<label class="opcaopag">
    <input type="radio" name="formapag" value="PIX" required>
    <span class="cartaopag">PIX</span>
</label>
</div>
</div>

<button type="submit" name="finalizar" class="botao"> Finalizar Compra </button>
</form>

</div>

<?php } else { ?>

<div class="final">
    <div class="finalresumo">
    <h3 class="finaltitulo">Pedido realizado!</h3>
    <p><?php echo $mensagem; ?></p>
    <br>
    <a href="main.php" class="botao">
    Voltar para a loja
    </a>
</div>
</div>

<?php } ?>

</section>
</body>
</html>