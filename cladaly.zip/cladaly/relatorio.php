<?php
$titulopag = "Relatório de Pedidos";
include "header.php";

$sql = "SELECT
p.id,
DATE_FORMAT(p.data_pedido,'%d/%m/%Y') AS data,
p.total,
c.nome AS cliente,
pg.forma_pagamento,
e.endereco
FROM pedidos p
INNER JOIN clientes c ON c.id = p.cliente_id
LEFT JOIN pagamentos pg ON pg.pedido_id = p.id
LEFT JOIN entregas e ON e.pedido_id = p.id
ORDER BY p.data_pedido DESC";

$resultado = mysqli_query($conexao, $sql);
?>

<div class="banner bannerprod">
    <h1>Relatório de Pedidos</h1>
</div>

<section class="secao">
    
<div class="reltabela">

<?php if (mysqli_num_rows($resultado) == 0) { ?>

    <div class="vazio">
        <p>Nenhum pedido encontrado.</p>
    </div>

<?php } else { ?>

<table class="tabela">
<tr>
<th>Pedido</th>
<th>Data</th>
<th>Cliente</th>
<th>Pagamento</th>
<th>Endereço</th>
<th>Total</th>
</tr>

<?php while ($pedido = mysqli_fetch_assoc($resultado)) { ?>

<tr>
<td>#<?php echo $pedido["id"]; ?></td>
<td><?php echo $pedido["data"]; ?></td>
<td><?php echo $pedido["cliente"]; ?></td>
<td><?php echo $pedido["forma_pagamento"]; ?></td>
<td><?php echo $pedido["endereco"]; ?></td>
<td> R$ <?php echo number_format($pedido["total"],2,",","."); ?> </td>
</tr>

<?php } ?>
</table>
<?php } ?>

<div class="relvoltar">
<a href="main.php" class="botao botaolinha">
    Voltar para a loja
</a>
</div>
</div>

</section>
</body>
</html>